module.exports = {
    APIKey: '977124034',
    keyfrom:'Skykai521'
}